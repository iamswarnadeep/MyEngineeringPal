-- MySQL dump 10.13  Distrib 5.5.62, for Linux (x86_64)
--
-- Host: localhost    Database: sql_tintforum_ml
-- ------------------------------------------------------
-- Server version	5.5.62-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tf_answers`
--

DROP TABLE IF EXISTS `tf_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `q_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_answers`
--

LOCK TABLES `tf_answers` WRITE;
/*!40000 ALTER TABLE `tf_answers` DISABLE KEYS */;
INSERT INTO `tf_answers` VALUES (1,1001,1,'Ans ok',0,0,'2022-07-25 07:24:55','0000-00-00 00:00:00',1),(2,1001,1,'Write a long answer......&nbsp;',0,0,'2022-07-25 18:08:44','0000-00-00 00:00:00',1);
/*!40000 ALTER TABLE `tf_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_awards`
--

DROP TABLE IF EXISTS `tf_awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_awards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `reason` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_awards`
--

LOCK TABLES `tf_awards` WRITE;
/*!40000 ALTER TABLE `tf_awards` DISABLE KEYS */;
/*!40000 ALTER TABLE `tf_awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_file_upload`
--

DROP TABLE IF EXISTS `tf_file_upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_file_upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `size` varchar(30) NOT NULL,
  `title` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_file_upload`
--

LOCK TABLES `tf_file_upload` WRITE;
/*!40000 ALTER TABLE `tf_file_upload` DISABLE KEYS */;
/*!40000 ALTER TABLE `tf_file_upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_follows_rules`
--

DROP TABLE IF EXISTS `tf_follows_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_follows_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `obj_id` int(11) NOT NULL,
  `follow_date` datetime NOT NULL,
  `obj_type` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_follows_rules`
--

LOCK TABLES `tf_follows_rules` WRITE;
/*!40000 ALTER TABLE `tf_follows_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `tf_follows_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_functions`
--

DROP TABLE IF EXISTS `tf_functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_functions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `function` varchar(30) NOT NULL,
  `value` text NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='misc functions goes here';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_functions`
--

LOCK TABLES `tf_functions` WRITE;
/*!40000 ALTER TABLE `tf_functions` DISABLE KEYS */;
INSERT INTO `tf_functions` VALUES (1,'general_settings','a:11:{s:9:\"site_name\";s:10:\"tint forum\";s:16:\"site_description\";s:21:\"Questions and Answers\";s:13:\"site_keywords\";s:23:\"Questions,Answers,Quora\";s:11:\"site_status\";s:1:\"1\";s:9:\"site_lang\";s:7:\"English\";s:11:\"closure_msg\";s:48:\"Site closed for maintenance.. please stay tuned!\";s:8:\"url_type\";s:4:\"slug\";s:10:\"q_approval\";s:1:\"0\";s:10:\"a_approval\";s:1:\"0\";s:9:\"reg_group\";s:1:\"3\";s:13:\"public_access\";s:1:\"1\";}',''),(2,'privacy-policy','',''),(3,'about-us','',''),(4,'contact-us','',''),(5,'terms','',''),(6,'profanity_filter','a55,a55hole,aeolus,ahole,anal,analprobe,anilingus,anus,areola,areole,arian,aryan,ass,assbang,assbanged,assbangs,asses,assfuck,assfucker,assh0le,asshat,assho1e,ass hole,assholes,assmaster,assmunch,asswipe,asswipes,azazel,azz,b1tch,babe,babes,ballsack,bang,banger,barf,bastard,bastards,bawdy,beaner,beardedclam,beastiality,beatch,beater,beaver,beer,beeyotch,beotch,biatch,bigtits,big tits,bimbo,bitch,bitched,bitches,bitchy,blow job,blow,blowjob,blowjobs,bod,bodily,boink,bollock,bollocks,bollok,bone,boned,boner,boners,bong,boob,boobies,boobs,booby,booger,bookie,bootee,bootie,booty,booze,boozer,boozy,bosom,bosomy,bowel,bowels,bra,brassiere,breast,breasts,bugger,bukkake,bullshit,bull shit,bullshits,bullshitted,bullturds,bung,busty,butt,butt fuck,buttfuck,buttfucker,buttfucker,buttplug,c.0.c.k,c.o.c.k.,c.u.n.t,c0ck,c-0-c-k,caca,cahone,cameltoe,carpetmuncher,cawk,cervix,chinc,chincs,chink,chink,chode,chodes,cl1t,climax,clit,clitoris,clitorus,clits,clitty,cocain,cocaine,cock,c-o-c-k,cockblock,cockholster,cockknocker,cocks,cocksmoker,cocksucker,cock sucker,coital,commie,condom,coon,coons,corksucker,crabs,crack,cracker,crackwhore,crap,crappy,cum,cummin,cumming,cumshot,cumshots,cumslut,cumstain,cunilingus,cunnilingus,cunny,cunt,cunt,c-u-n-t,cuntface,cunthunter,cuntlick,cuntlicker,cunts,d0ng,d0uch3,d0uche,d1ck,d1ld0,d1ldo,dago,dagos,dammit,damn,damned,damnit,dawgie-style,dick,dickbag,dickdipper,dickface,dickflipper,dickhead,dickheads,dickish,dick-ish,dickripper,dicksipper,dickweed,dickwhipper,dickzipper,diddle,dike,dildo,dildos,diligaf,dillweed,dimwit,dingle,dipship,doggie-style,doggy-style,dong,doofus,doosh,dopey,douch3,douche,douchebag,douchebags,douchey,drunk,dumass,dumbass,dumbasses,dummy,dyke,dykes,ejaculate,enlargement,erect,erection,erotic,essohbee,extacy,extasy,f.u.c.k,fack,fag,fagg,fagged,faggit,faggot,fagot,fags,faig,faigt,fannybandit,fart,fartknocker,fat,felch,felcher,felching,fellate,fellatio,feltch,feltcher,fisted,fisting,fisty,floozy,foad,fondle,foobar,foreskin,freex,frigg,frigga,fubar,fuck,f-u-c-k,fuckass,fucked,fucked,fucker,fuckface,fuckin,fucking,fucknugget,fucknut,fuckoff,fucks,fucktard,fuck-tard,fuckup,fuckwad,fuckwit,fudgepacker,fuk,fvck,fxck,gae,gai,ganja,gay,gays,gey,gfy,ghay,ghey,gigolo,glans,goatse,godamn,godamnit,goddam,goddammit,goddamn,goldenshower,gonad,gonads,gook,gooks,gringo,gspot,g-spot,gtfo,guido,h0m0,h0mo,handjob,hard on,he11,hebe,heeb,hell,hemp,heroin,herp,herpes,herpy,hitler,hiv,hobag,hom0,homey,homo,homoey,honky,hooch,hookah,hooker,hoor,hootch,hooter,hooters,horny,hump,humped,humping,hussy,hymen,inbred,incest,injun,j3rk0ff,jackass,jackhole,jackoff,jap,japs,jerk,jerk0ff,jerked,jerkoff,jism,jiz,jizm,jizz,jizzed,junkie,junky,kike,kikes,kill,kinky,kkk,klan,knobend,kooch,kooches,kootch,kraut,kyke,labia,lech,leper,lesbians,lesbo,lesbos,lez,lezbian,lezbians,lezbo,lezbos,lezzie,lezzies,lezzy,lmao,lmfao,loin,loins,lube,lusty,mams,massa,masterbate,masterbating,masterbation,masturbate,masturbating,masturbation,maxi,menses,menstruate,menstruation,meth,m-fucking,mofo,molest,moolie,moron,motherfucka,motherfucker,motherfucking,mtherfucker,mthrfucker,mthrfucking,muff,muffdiver,murder,muthafuckaz,muthafucker,mutherfucker,mutherfucking,muthrfucking,nad,nads,naked,napalm,nappy,nazi,nazism,negro,nigga,niggah,niggas,niggaz,nigger,nigger,niggers,niggle,niglet,nimrod,ninny,nipple,nooky,nympho,opiate,opium,oral,orally,organ,orgasm,orgasmic,orgies,orgy,ovary,ovum,ovums,p.u.s.s.y.,paddy,paki,pantie,panties,panty,pastie,pasty,pcp,pecker,pedo,pedophile,pedophilia,pedophiliac,pee,peepee,penetrate,penetration,penial,penile,penis,perversion,peyote,phalli,phallic,phuck,pillowbiter,pimp,pinko,piss,pissed,pissoff,piss-off,pms,polack,pollock,poon,poontang,porn,porno,pornography,pot,potty,prick,prig,prostitute,prude,pube,pubic,pubis,punkass,punky,puss,pussies,pussy,pussypounder,puto,queaf,queef,queef,queer,queero,queers,quicky,quim,racy,rape,raped,raper,rapist,raunch,rectal,rectum,rectus,reefer,reetard,reich,retard,retarded,revue,rimjob,ritard,rtard,r-tard,rum,rump,rumprammer,ruski,s.h.i.t.,s.o.b.,s0b,sadism,sadist,scag,scantily,schizo,schlong,screw,screwed,scrog,scrot,scrote,scrotum,scrud,scum,seaman,seamen,seduce,semen,sex,sexual,sh1t,s-h-1-t,shamedame,shit,s-h-i-t,shite,shiteater,shitface,shithead,shithole,shithouse,shits,shitt,shitted,shitter,shitty,shiz,sissy,skag,skank,slave,sleaze,sleazy,slut,slutdumper,slutkiss,sluts,smegma,smut,smutty,snatch,sniper,snuff,s-o-b,sodom,souse,soused,sperm,spic,spick,spik,spiks,spooge,spunk,steamy,stfu,stiffy,stoned,strip,stroke,stupid,suck,sucked,sucking,sumofabiatch,t1t,tampon,tard,tawdry,teabagging,teat,terd,teste,testee,testes,testicle,testis,thrust,thug,tinkle,tit,titfuck,titi,tits,tittiefucker,titties,titty,tittyfuck,tittyfucker,toke,toots,tramp,transsexual,trashy,tubgirl,turd,tush,twat,twats,ugly,undies,unwed,urinal,urine,uterus,uzi,vag,vagina,valium,viagra,virgin,vixen,vodka,vomit,voyeur,vulgar,vulva,wad,wang,wank,wanker,wazoo,wedgie,weed,weenie,weewee,weiner,weirdo,wench,wetback,wh0re,wh0reface,whitey,whiz,whoralicious,whore,whorealicious,whored,whoreface,whorehopper,whorehouse,whores,whoring,wigger,womb,woody,wop,wtf,x-rated,xxx,yeasty,yobbo,zoophile',''),(7,'admanager1','&nbsp;',''),(8,'admanager2','&nbsp;','');
/*!40000 ALTER TABLE `tf_functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_groups`
--

DROP TABLE IF EXISTS `tf_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `privileges` text NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_groups`
--

LOCK TABLES `tf_groups` WRITE;
/*!40000 ALTER TABLE `tf_groups` DISABLE KEYS */;
INSERT INTO `tf_groups` VALUES (1,'Admin','index.read,pages.read,error-404.read,index.notifications,index.post,index.feed,feed.follow,questions.read,questions.interact,post.read,questions.create,questions.power,questions.update,questions.delete,answers.read,answers.create,answers.power,answers.update,answers.delete,users.read,users.follow,users.update,users.changepass,users.changemail,users.delete,admin.read,dashboard.read,general_settings.update,profanity_filter.update,pending.read,pending.update,pages.read,pages.update,adminusers.read,adminusers.update,adminusers.changepass,adminusers.changemail,adminusers.changeusername,adminusers.power,adminusers.suspend,adminusers.delete,admintopics.read,admintopics.update,admintopics.delete,admanager.read,admanager.update,groups.read,groups.create,groups.update,groups.delete',0),(2,'Guest','index.read,pages.read,error-404.read,questions.read,users.read',0),(3,'Registered Users','index.read,pages.read,error-404.read,index.notifications,index.post,index.feed,feed.follow,questions.read,questions.interact,post.read,questions.create,questions.update,answers.read,answers.create,answers.update,users.read,users.follow,users.update,users.changepass,users.delete',0);
/*!40000 ALTER TABLE `tf_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_likes_rules`
--

DROP TABLE IF EXISTS `tf_likes_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_likes_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `obj_id` int(11) NOT NULL,
  `like_date` datetime NOT NULL,
  `obj_type` varchar(30) NOT NULL,
  `type` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_likes_rules`
--

LOCK TABLES `tf_likes_rules` WRITE;
/*!40000 ALTER TABLE `tf_likes_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `tf_likes_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_logs`
--

DROP TABLE IF EXISTS `tf_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `action` varchar(30) NOT NULL,
  `msg` text NOT NULL,
  `done_at` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_logs`
--

LOCK TABLES `tf_logs` WRITE;
/*!40000 ALTER TABLE `tf_logs` DISABLE KEYS */;
INSERT INTO `tf_logs` VALUES (1,1,0,'Login','Login to system','2022-07-24 15:07:55','113.21.69.206'),(2,1,0,'Login','Login to system','2022-07-24 15:14:31','113.21.69.206'),(3,1,0,'Login','Login to system','2022-07-24 15:29:32','113.21.69.206'),(4,1001,0,'Login','Login to system','2022-07-25 07:24:19','113.21.69.206'),(5,1,0,'Login','Login to system','2022-07-25 17:52:32','117.227.87.32'),(6,1001,0,'Login','Login to system','2022-07-25 18:05:04','113.21.67.147'),(7,1,0,'Login','Login to system','2022-07-28 07:07:44','113.21.68.40'),(8,1003,0,'Login','Login to system','2022-08-13 06:21:11','113.21.71.100'),(9,1,0,'Login','Login to system','2022-08-13 07:25:01','113.21.71.100'),(10,1,0,'Login','Login to system','2022-08-13 07:45:59','113.21.71.100');
/*!40000 ALTER TABLE `tf_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_notifications`
--

DROP TABLE IF EXISTS `tf_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `msg` varchar(300) NOT NULL,
  `link` varchar(300) NOT NULL,
  `created_at` datetime NOT NULL,
  `viewed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_notifications`
--

LOCK TABLES `tf_notifications` WRITE;
/*!40000 ALTER TABLE `tf_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `tf_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_questions`
--

DROP TABLE IF EXISTS `tf_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `feed` varchar(99) NOT NULL,
  `content` text NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  `answers` int(11) NOT NULL,
  `follows` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `slug` varchar(500) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `anonymous` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_questions`
--

LOCK TABLES `tf_questions` WRITE;
/*!40000 ALTER TABLE `tf_questions` DISABLE KEYS */;
INSERT INTO `tf_questions` VALUES (1,1001,'Write a question you want to ask? ','General','',0,0,2,0,18,'write-a-question-you-want-to-ask','2022-07-25 07:24:34','2022-07-25 18:09:44',1,0),(2,1003,'Question naki add kora jachhe na?? ','General','',0,0,0,0,2,'Question-naki-add-kora-jachhe-na','2022-08-13 06:21:36','0000-00-00 00:00:00',1,0);
/*!40000 ALTER TABLE `tf_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_reports`
--

DROP TABLE IF EXISTS `tf_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `obj_id` int(11) NOT NULL,
  `obj_type` varchar(30) NOT NULL,
  `report_date` datetime NOT NULL,
  `info` varchar(300) NOT NULL,
  `result` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_reports`
--

LOCK TABLES `tf_reports` WRITE;
/*!40000 ALTER TABLE `tf_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `tf_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_tags`
--

DROP TABLE IF EXISTS `tf_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(99) NOT NULL,
  `follows` int(11) NOT NULL,
  `description` text NOT NULL,
  `avatar` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `used` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_tags`
--

LOCK TABLES `tf_tags` WRITE;
/*!40000 ALTER TABLE `tf_tags` DISABLE KEYS */;
INSERT INTO `tf_tags` VALUES (1,'General',0,'',0,0,3);
/*!40000 ALTER TABLE `tf_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tf_users`
--

DROP TABLE IF EXISTS `tf_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tf_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(99) NOT NULL,
  `prvlg_group` int(11) NOT NULL,
  `email` varchar(99) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `avatar` int(11) NOT NULL,
  `username` varchar(99) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `l_name` varchar(30) NOT NULL,
  `comment` varchar(199) NOT NULL,
  `about` varchar(300) NOT NULL,
  `hybridauth_provider_name` varchar(255) NOT NULL,
  `hybridauth_provider_uid` varchar(255) NOT NULL,
  `follows` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `joined` datetime NOT NULL,
  `disabled` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=utf8 COMMENT='users table to access cp';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tf_users`
--

LOCK TABLES `tf_users` WRITE;
/*!40000 ALTER TABLE `tf_users` DISABLE KEYS */;
INSERT INTO `tf_users` VALUES (1,'$P$ByDWDdIyGLxZCk614gaPWGk3D.Co2w/',1,'admin@gmail.com','','',0,'admin','Swarnadeep','Karmakar','Super admin','','','',0,0,'0000-00-00 00:00:00',0,0);
/*!40000 ALTER TABLE `tf_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'tintforum_db'
--

--
-- Dumping routines for database 'tintforum_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-13  6:45:24
